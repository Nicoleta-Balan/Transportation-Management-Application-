create function calculate_total_revenue() returns numeric
    language plpgsql
as
$$
DECLARE
    v_total_revenue DECIMAL(15, 2);
BEGIN
    SELECT COALESCE(SUM(total_fare), 0.00) INTO v_total_revenue
    FROM reservations
    WHERE status = 'CONFIRMED';
    
    RETURN v_total_revenue;
END;
$$;

alter function calculate_total_revenue() owner to tms_user;

