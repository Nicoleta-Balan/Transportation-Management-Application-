create procedure update_route_availability(IN p_route_id bigint)
    language plpgsql
as
$$
DECLARE
    v_total_capacity INTEGER;
    v_booked_seats INTEGER;
    v_available_seats INTEGER;
BEGIN
    -- Get route capacity
    SELECT vehicle_capacity INTO v_total_capacity
    FROM routes
    WHERE id = p_route_id;
    
    IF v_total_capacity IS NULL THEN
        RAISE EXCEPTION 'Route % not found', p_route_id;
    END IF;
    
    -- Calculate booked seats (only confirmed and pending reservations)
    SELECT COALESCE(SUM(seat_count), 0) INTO v_booked_seats
    FROM reservations
    WHERE route_id = p_route_id
      AND status IN ('PENDING', 'CONFIRMED');
    
    -- Calculate available seats
    v_available_seats := GREATEST(0, v_total_capacity - v_booked_seats);
    
    -- Insert or update route availability
    INSERT INTO route_availability (route_id, total_capacity, booked_seats, available_seats, last_updated)
    VALUES (p_route_id, v_total_capacity, v_booked_seats, v_available_seats, CURRENT_TIMESTAMP)
    ON CONFLICT (route_id) 
    DO UPDATE SET
        total_capacity = EXCLUDED.total_capacity,
        booked_seats = EXCLUDED.booked_seats,
        available_seats = EXCLUDED.available_seats,
        last_updated = CURRENT_TIMESTAMP;
END;
$$;

alter procedure update_route_availability(bigint) owner to tms_user;

