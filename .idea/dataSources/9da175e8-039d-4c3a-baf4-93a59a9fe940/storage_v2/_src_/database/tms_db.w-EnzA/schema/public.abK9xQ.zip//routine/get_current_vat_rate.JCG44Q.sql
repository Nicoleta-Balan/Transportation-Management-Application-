create function get_current_vat_rate() returns numeric
    language plpgsql
as
$$
DECLARE
    current_rate DECIMAL(5, 2);
BEGIN
    SELECT rate_percentage INTO current_rate
    FROM vat_rates
    WHERE effective_from <= CURRENT_TIMESTAMP
      AND (effective_to IS NULL OR effective_to > CURRENT_TIMESTAMP)
    ORDER BY effective_from DESC
    LIMIT 1;
    
    -- If no VAT rate found, return 0
    IF current_rate IS NULL THEN
        RETURN 0.00;
    END IF;
    
    RETURN current_rate;
END;
$$;

alter function get_current_vat_rate() owner to tms_user;

