create function calculate_reservation_fare(p_route_id bigint, p_passenger_category character varying, p_vehicle_class character varying, p_seat_count integer, p_reservation_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP)
    returns TABLE(base_fare numeric, vat_amount numeric, total_fare numeric, vat_rate numeric)
    language plpgsql
as
$$
DECLARE
    v_base_price DECIMAL(10, 2);
    v_vat_rate DECIMAL(5, 2);
    v_calculated_fare RECORD;
BEGIN
    -- Get base price
    v_base_price := get_active_fare_policy(p_route_id, p_passenger_category, p_vehicle_class, p_reservation_date);
    
    -- Get VAT rate for the reservation date
    v_vat_rate := get_vat_rate_for_date(p_reservation_date);
    
    -- Calculate fare with VAT
    SELECT * INTO v_calculated_fare
    FROM calculate_fare_with_vat(v_base_price, p_seat_count, v_vat_rate);
    
    RETURN QUERY SELECT 
        v_calculated_fare.base_fare,
        v_calculated_fare.vat_amount,
        v_calculated_fare.total_fare,
        v_vat_rate;
END;
$$;

alter function calculate_reservation_fare(bigint, varchar, varchar, integer, timestamp) owner to tms_user;

