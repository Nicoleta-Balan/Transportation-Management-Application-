create function check_seat_availability(p_route_id bigint, p_required_seats integer) returns boolean
    language plpgsql
as
$$
DECLARE
    v_available_seats INTEGER;
BEGIN
    SELECT available_seats INTO v_available_seats
    FROM route_availability
    WHERE route_id = p_route_id;
    
    -- If route_availability doesn't exist, return false
    IF v_available_seats IS NULL THEN
        RETURN FALSE;
    END IF;
    
    RETURN v_available_seats >= p_required_seats;
END;
$$;

alter function check_seat_availability(bigint, integer) owner to tms_user;

