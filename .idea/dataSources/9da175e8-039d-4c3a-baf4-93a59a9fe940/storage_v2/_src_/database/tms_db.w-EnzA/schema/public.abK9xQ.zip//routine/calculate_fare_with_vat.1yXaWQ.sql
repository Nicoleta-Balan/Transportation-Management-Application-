create function calculate_fare_with_vat(p_base_price numeric, p_seat_count integer, p_vat_rate numeric DEFAULT NULL::numeric)
    returns TABLE(base_fare numeric, vat_amount numeric, total_fare numeric)
    language plpgsql
as
$$
DECLARE
    v_vat_rate DECIMAL(5, 2);
    v_base_total DECIMAL(10, 2);
    v_vat_amount DECIMAL(10, 2);
    v_total_fare DECIMAL(10, 2);
BEGIN
    -- Get VAT rate if not provided
    IF p_vat_rate IS NULL THEN
        v_vat_rate := get_current_vat_rate();
    ELSE
        v_vat_rate := p_vat_rate;
    END IF;
    
    -- Calculate base fare total
    v_base_total := p_base_price * p_seat_count;
    
    -- Calculate VAT amount
    v_vat_amount := ROUND(v_base_total * (v_vat_rate / 100.0), 2);
    
    -- Calculate total fare
    v_total_fare := v_base_total + v_vat_amount;
    
    RETURN QUERY SELECT v_base_total, v_vat_amount, v_total_fare;
END;
$$;

alter function calculate_fare_with_vat(numeric, integer, numeric) owner to tms_user;

