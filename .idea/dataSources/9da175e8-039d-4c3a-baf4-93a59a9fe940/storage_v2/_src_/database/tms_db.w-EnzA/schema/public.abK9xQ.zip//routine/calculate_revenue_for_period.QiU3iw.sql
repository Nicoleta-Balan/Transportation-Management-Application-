create function calculate_revenue_for_period(p_start_date timestamp without time zone, p_end_date timestamp without time zone)
    returns TABLE(total_revenue numeric, total_vat numeric, net_revenue numeric, reservation_count bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT 
        COALESCE(SUM(total_fare), 0.00) AS total_revenue,
        COALESCE(SUM(vat_amount), 0.00) AS total_vat,
        COALESCE(SUM(base_fare), 0.00) AS net_revenue,
        COUNT(*) AS reservation_count
    FROM reservations
    WHERE status = 'CONFIRMED'
      AND created_at BETWEEN p_start_date AND p_end_date;
END;
$$;

alter function calculate_revenue_for_period(timestamp, timestamp) owner to tms_user;

