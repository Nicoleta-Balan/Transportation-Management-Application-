create function get_vat_rate_for_date(check_date timestamp without time zone) returns numeric
    language plpgsql
as
$$
DECLARE
    rate DECIMAL(5, 2);
BEGIN
    SELECT rate_percentage INTO rate
    FROM vat_rates
    WHERE effective_from <= check_date
      AND (effective_to IS NULL OR effective_to > check_date)
    ORDER BY effective_from DESC
    LIMIT 1;
    
    IF rate IS NULL THEN
        RETURN 0.00;
    END IF;
    
    RETURN rate;
END;
$$;

alter function get_vat_rate_for_date(timestamp) owner to tms_user;

