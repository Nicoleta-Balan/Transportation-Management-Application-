create procedure update_route_statistics(IN p_route_id bigint)
    language plpgsql
as
$$
DECLARE
    v_stats RECORD;
BEGIN
    -- Calculate statistics
    SELECT * INTO v_stats
    FROM calculate_route_statistics(p_route_id);
    
    -- Update route statistics table
    INSERT INTO route_statistics (
        route_id,
        total_reservations,
        confirmed_reservations,
        cancelled_reservations,
        total_revenue,
        average_occupancy_rate,
        last_calculated
    )
    VALUES (
        p_route_id,
        v_stats.total_reservations,
        v_stats.confirmed_reservations,
        v_stats.cancelled_reservations,
        v_stats.total_revenue,
        v_stats.average_occupancy_rate,
        CURRENT_TIMESTAMP
    )
    ON CONFLICT (route_id)
    DO UPDATE SET
        total_reservations = EXCLUDED.total_reservations,
        confirmed_reservations = EXCLUDED.confirmed_reservations,
        cancelled_reservations = EXCLUDED.cancelled_reservations,
        total_revenue = EXCLUDED.total_revenue,
        average_occupancy_rate = EXCLUDED.average_occupancy_rate,
        last_calculated = CURRENT_TIMESTAMP;
END;
$$;

alter procedure update_route_statistics(bigint) owner to tms_user;

