create function calculate_route_statistics(p_route_id bigint)
    returns TABLE(total_reservations bigint, confirmed_reservations bigint, cancelled_reservations bigint, total_revenue numeric, average_occupancy_rate numeric)
    language plpgsql
as
$$
DECLARE
    v_total_capacity INTEGER;
    v_total_reservations BIGINT;
    v_confirmed_reservations BIGINT;
    v_cancelled_reservations BIGINT;
    v_total_revenue DECIMAL(15, 2);
    v_avg_occupancy DECIMAL(5, 2);
BEGIN
    -- Get route capacity
    SELECT vehicle_capacity INTO v_total_capacity
    FROM routes
    WHERE id = p_route_id;
    
    IF v_total_capacity IS NULL THEN
        RAISE EXCEPTION 'Route % not found', p_route_id;
    END IF;
    
    -- Calculate statistics
    SELECT 
        COUNT(*),
        COUNT(*) FILTER (WHERE status = 'CONFIRMED'),
        COUNT(*) FILTER (WHERE status = 'CANCELLED'),
        COALESCE(SUM(total_fare) FILTER (WHERE status = 'CONFIRMED'), 0.00)
    INTO 
        v_total_reservations,
        v_confirmed_reservations,
        v_cancelled_reservations,
        v_total_revenue
    FROM reservations
    WHERE route_id = p_route_id;
    
    -- Calculate average occupancy (simplified: based on confirmed reservations)
    IF v_total_reservations > 0 THEN
        SELECT COALESCE(SUM(seat_count), 0) INTO v_avg_occupancy
        FROM reservations
        WHERE route_id = p_route_id AND status = 'CONFIRMED';
        
        v_avg_occupancy := ROUND((v_avg_occupancy::DECIMAL / v_total_capacity::DECIMAL) * 100, 2);
    ELSE
        v_avg_occupancy := 0.00;
    END IF;
    
    RETURN QUERY SELECT 
        v_total_reservations,
        v_confirmed_reservations,
        v_cancelled_reservations,
        v_total_revenue,
        v_avg_occupancy;
END;
$$;

alter function calculate_route_statistics(bigint) owner to tms_user;

