create function get_active_fare_policy(p_route_id bigint, p_passenger_category character varying, p_vehicle_class character varying, p_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP) returns numeric
    language plpgsql
as
$$
DECLARE
    fare_price DECIMAL(10, 2);
BEGIN
    SELECT base_price INTO fare_price
    FROM fare_policies
    WHERE route_id = p_route_id
      AND passenger_category = p_passenger_category
      AND vehicle_class = p_vehicle_class
      AND status = 'ACTIVE'
      AND effective_from <= p_date
      AND (effective_to IS NULL OR effective_to > p_date)
    ORDER BY effective_from DESC
    LIMIT 1;
    
    IF fare_price IS NULL THEN
        RAISE EXCEPTION 'No active fare policy found for route %, category %, class %', 
            p_route_id, p_passenger_category, p_vehicle_class;
    END IF;
    
    RETURN fare_price;
END;
$$;

alter function get_active_fare_policy(bigint, varchar, varchar, timestamp) owner to tms_user;

