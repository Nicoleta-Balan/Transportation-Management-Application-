create function calculate_route_revenue(p_route_id bigint) returns numeric
    language plpgsql
as
$$
DECLARE
    v_revenue DECIMAL(15, 2);
BEGIN
    SELECT COALESCE(SUM(total_fare), 0.00) INTO v_revenue
    FROM reservations
    WHERE route_id = p_route_id
      AND status = 'CONFIRMED';
    
    RETURN v_revenue;
END;
$$;

alter function calculate_route_revenue(bigint) owner to tms_user;

