create function calculate_booked_seats(p_route_id bigint, p_departure_time timestamp without time zone, p_arrival_time timestamp without time zone) returns integer
    language plpgsql
as
$$
DECLARE
    v_booked_seats INTEGER;
BEGIN
    -- Calculate seats for overlapping reservations
    -- Two reservations overlap if: p.departure < res.arrival AND p.arrival > res.departure
    SELECT COALESCE(SUM(seat_count), 0) INTO v_booked_seats
    FROM reservations
    WHERE route_id = p_route_id
      AND status IN ('PENDING', 'CONFIRMED')
      AND departure_time < p_arrival_time
      AND arrival_time > p_departure_time;
    
    RETURN v_booked_seats;
END;
$$;

alter function calculate_booked_seats(bigint, timestamp, timestamp) owner to tms_user;

