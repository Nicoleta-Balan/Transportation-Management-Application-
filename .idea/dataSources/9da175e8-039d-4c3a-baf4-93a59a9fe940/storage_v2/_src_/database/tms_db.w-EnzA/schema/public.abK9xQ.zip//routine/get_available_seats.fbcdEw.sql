create function get_available_seats(p_route_id bigint) returns integer
    language plpgsql
as
$$
DECLARE
    v_available_seats INTEGER;
BEGIN
    SELECT available_seats INTO v_available_seats
    FROM route_availability
    WHERE route_id = p_route_id;
    
    IF v_available_seats IS NULL THEN
        RETURN 0;
    END IF;
    
    RETURN v_available_seats;
END;
$$;

alter function get_available_seats(bigint) owner to tms_user;

